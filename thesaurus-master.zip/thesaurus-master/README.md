
## Installation

First, install [Miniconda](https://conda.io/projects/conda/en/latest/user-guide/install/index.html).  Next, clone the repo and set up the Python environment.

```
cd thesaurus
conda create -n thesaurus python=3.7
conda activate thesaurus
pip install -r requirements.txt
```

You should then have everything you need to run the scripts.  The scripts are all accessible through `cli.py` and are self-documenting:

```
cd cli
python cli.py --help
python cli.py bridge --help
python cli.py bridge words --help
```

## Bridging two words

The algorithm starts from each word and builds two trees.  When the trees overlap, it checks to see whether the linkage is of an appropriate depth.  If it is, it prints the chain, and gives you the option to keep searching, or to eliminate problematic words.

For example, bridge two words:

```
python cli.py bridge words --a light --b dark
```

### Command-line flags

| Flag                          | Description                            | Default      |
| ----------------------------- | -------------------------------------- | ------------ |
| --a TEXT                      | Starting word                          | (required)   |
| --b TEXT                      | Ending word                            | (required)   |
| --include_oe                  | Include OE/archaic words               | (off)        |
| --include_slang               | Include slang/colloquial words         | (off)        |
| --include_scots               | Include Scots words                    | (off)        |
| --shuffle/--no_shuffle        | Shuffle the queues                     | --shuffle    |
| --words_per_step INTEGER      | Number of words to check per step      | 20           |
| --categories_per_word INTEGER | Number of categories to check per word | 3            |
| --min_depth INTEGER           | Minimum depth of matches               | 10           |
| --use_shortest_path           | Use shortest path between words        | (off)        |
| --help                        | Show this message and exit.            |              |

### Resolution and depth

Using `--min_depth` you can specify how many hops you want.  This counts words plus categories, so for 10 hops we will get at least 4 words and 6 categories in between.

You can vary the search resolution by specifying how many words/categories are searched at a time.  With each pass, we shuffle the list of unseen words and categories, so you can force a broader or deeper search by tweaking these numbers.

When computing the chain of synonyms, we descend the category tree from word to word, based on when the words were seen.  This process can be short-circuited by finding the deepest word in the category, rather than the word adjacent from the traversal.  This ignores the `--min_depth` parameter.  But this can make the paths very short, so instead we prefer finding longer paths.

### Breaking the chain

Finally, after printing the chain, you have the option to cut the chain or to keep searching.  Each word in the chain will have a number assigned to it, and you just type in this number, or hit enter to find new chains.

Cutting the chain  will clear the trees and restart the process.  If the combination is found again, it will be ignored.  

All the words and categories are cached in the `data_store` directory, which speeds up the process of finding new synonyms.  The data is stored as JSON.  This folder can grow to the hundreds of megabytes, if you've done a lot of searches, but it can be safely removed when you're finished.

## The Finneganizer

Create a portmonteau using synonyms of pieces of words:

```
./cli.py bridge finnegan -a word
```

This command will split a word into sub-words, and then find synonyms for these pieces and re-combine them.

| Flag                          | Description                                  | Default      |
| ----------------------------- | -------------------------------------------- | ------------ |
| --a TEXT                      | Starting word                                | (required)   |
| --length INTEGER              | Minimum length of word to use                | 2            |
| --splits INTEGER              | Number of word-pieces to use                 | 2            |
| --categories INTEGER          | Number of categories to search per fragment  | 2            |
| --reuse_word                  | Whether to reuse pieces of the original word | (off)        |
| --include_oe                  | Include OE/archaic words                     | (off)        |
| --include_slang               | Include slang/colloquial words               | (off)        |
| --include_scots               | Include Scots words                          | (off)        |
| --include_compound            | Include compound words that contain a hyphen | (off)        |

### All rights reserved

This software is private ...  We retain all copyright in the code itself.  We disclaim all responsibility or liability resulting in its usage. 

2020
