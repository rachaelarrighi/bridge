#!/usr/bin/env python

# --------------------------------------------------------
# VFRAME Synthetic Data cli
# --------------------------------------------------------

import click

from app.settings import app_cfg
from app.utils import logger_utils
from app.utils.click_factory import ClickSimple

# --------------------------------------------------------
# Entrypoint
# --------------------------------------------------------

if __name__ == '__main__':

  import os
  import sys
  import argparse

  # argparse: intercept group
  argv_tmp = sys.argv
  sys.argv = sys.argv[:2]
  ap = argparse.ArgumentParser('\033[1m\033[94mHistorical Thesaurus\033[0m')
  ap.add_argument('group', choices=app_cfg.CLICK_GROUPS.keys())
  args = ap.parse_args()
  sys.argv = argv_tmp
  sys.argv.pop(1)  # remove group

  # click: parse rest of argv
  cc = ClickSimple.create(app_cfg.CLICK_GROUPS[args.group])
  @click.group(cls=cc, chain=False, no_args_is_help=True)
  @click.option('-v', '--verbose', 'opt_verbosity', count=True, default=4, 
    show_default=True,
    help='Verbosity: -v DEBUG, -vv INFO, -vvv WARN, -vvvv ERROR, -vvvvv CRITICAL')
  @click.pass_context
  def cli(ctx, opt_verbosity):
    """\033[1m\033[94mTHESAURUS\033[0m                                                
    """
    ctx.opts = {}
    logger_utils.Logger.create(verbosity=opt_verbosity) # init logger

  # ------------------------------------------------------------
  # entrypoint
  # ------------------------------------------------------------

  cli()
