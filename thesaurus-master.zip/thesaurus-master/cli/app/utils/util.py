import simplejson as json
import hashlib

def sha256(s):
  sha256 = hashlib.sha256()
  sha256.update(str.encode(s))
  return sha256.hexdigest()

def read_json(fn):
  with open(fn, 'r') as json_file:
    return json.load(json_file)

def write_json(fn, data):
  with open(fn, 'w') as outfile:
    json.dump(data, outfile)
