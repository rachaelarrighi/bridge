def is_oe(years):
  return (('oe' in years and 'oe-' not in years) or 'arch' in years)

def is_slang(years):
  return 'slang' in years or 'colloq' in years

def is_scots(years):
  return 'Scots' in years

def fix_word(word):
  if '<' in word or '/' in word or ',' in word:
    word = word.split("<")[0]
    word = word.split(",")[0]
    word = word.split("/")[0]
  return word.strip()

def is_compound_word(word):
  if '-' in word:
    return True
  if ' ' in word:
    return True
  return False
