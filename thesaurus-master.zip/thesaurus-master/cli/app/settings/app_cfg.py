import os
import logging
from pathlib import Path

from app.settings import types

# -----------------------------------------------------------------------------
# Logging options exposed for custom click Params
# -----------------------------------------------------------------------------

CLICK_GROUPS = {
  'api': 'commands/api',
  'bridge': 'commands/bridge',
}

# -----------------------------------------------------------------------------
# Paths
# -----------------------------------------------------------------------------

DIR_SELF = os.path.dirname(os.path.realpath(__file__))
DIR_ROOT = Path(DIR_SELF).parent.parent.parent

DATA_STORE = os.path.join(DIR_ROOT, 'data_store')

SEARCH_PATH = os.path.join(DATA_STORE, "search")
CATEGORY_PATH = os.path.join(DATA_STORE, "categories")

# -----------------------------------------------------------------------------
# Logging options exposed for custom click Params
# -----------------------------------------------------------------------------

LOGGER_NAME = 'CLI'
LOG = logging.getLogger(LOGGER_NAME)
LOGLEVELS = {
  types.LogLevel.DEBUG: logging.DEBUG,
  types.LogLevel.INFO: logging.INFO,
  types.LogLevel.WARN: logging.WARN,
  types.LogLevel.ERROR: logging.ERROR,
  types.LogLevel.CRITICAL: logging.CRITICAL
}
LOGLEVEL_OPT_DEFAULT = types.LogLevel.DEBUG.name
LOGFILE_FORMAT = "%(log_color)s%(levelname)-8s%(reset)s %(cyan)s%(filename)s:%(lineno)s:%(bold_cyan)s%(funcName)s() %(reset)s%(message)s"
