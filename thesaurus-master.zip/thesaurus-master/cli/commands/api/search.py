"""
Search for a word
"""

import click
import simplejson as json

from app.thesaurus.api import Thesaurus

@click.command()
@click.option('-i', '--word', 'opt_word', required=True,
  help='Word to search')
@click.pass_context
def cli(ctx, opt_word):
  """Search for a word
  """
  thesaurus = Thesaurus()
  results = thesaurus.search(opt_word)
  print(json.dumps(results, indent=2))
