"""
Browse a category
"""

import click
import simplejson as json

from app.thesaurus.api import Thesaurus

@click.command()
@click.option('-i', '--id', 'opt_cat_id', required=True,
  help='Category ID')
@click.pass_context
def cli(ctx, opt_cat_id):
  """Browse a category
  """
  thesaurus = Thesaurus()
  results = thesaurus.category(opt_cat_id)
  print(json.dumps(results, indent=2))
